"""passlib.setup - helpers used by passlib's setup.py script"""
