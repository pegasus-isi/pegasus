================
Atom Syndication
================

.. automodule:: werkzeug.contrib.atom

.. autoclass:: AtomFeed
   :members:

.. autoclass:: FeedEntry
