import pytest


@pytest.mark.xfail
def test_join():
    raise NotImplementedError
