import pytest


@pytest.mark.xfail
def test_get_membership_fields():
    raise NotImplementedError
