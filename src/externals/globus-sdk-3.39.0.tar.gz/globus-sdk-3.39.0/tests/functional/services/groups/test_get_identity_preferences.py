import pytest


@pytest.mark.xfail
def test_get_identity_preferences():
    raise NotImplementedError
