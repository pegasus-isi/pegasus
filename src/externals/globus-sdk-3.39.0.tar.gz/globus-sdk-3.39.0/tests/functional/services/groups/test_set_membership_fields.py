import pytest


@pytest.mark.xfail
def test_set_membership_fields():
    raise NotImplementedError
