import pytest


@pytest.mark.xfail
def test_reject_join_request():
    raise NotImplementedError
