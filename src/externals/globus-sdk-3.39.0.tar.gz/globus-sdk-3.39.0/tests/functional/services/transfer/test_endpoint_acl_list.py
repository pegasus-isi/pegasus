import pytest


@pytest.mark.xfail
def test_endpoint_acl_list():
    raise NotImplementedError
