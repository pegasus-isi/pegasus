import pytest


@pytest.mark.xfail
def test_endpoint_manager_task_pause_info():
    raise NotImplementedError
