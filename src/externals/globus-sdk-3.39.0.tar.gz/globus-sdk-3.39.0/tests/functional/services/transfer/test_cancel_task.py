import pytest


@pytest.mark.xfail
def test_cancel_task():
    raise NotImplementedError
