import pytest


@pytest.mark.xfail
def test_get_endpoint_role():
    raise NotImplementedError
