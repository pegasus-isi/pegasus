import pytest


@pytest.mark.xfail
def test_endpoint_manager_task_skipped_errors():
    raise NotImplementedError
