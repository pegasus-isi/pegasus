import pytest


@pytest.mark.xfail
def test_create_shared_endpoint():
    raise NotImplementedError
