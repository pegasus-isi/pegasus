import pytest


@pytest.mark.xfail
def test_bookmark_list():
    raise NotImplementedError
