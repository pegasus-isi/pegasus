import pytest


@pytest.mark.xfail
def test_endpoint_manager_monitored_endpoints():
    raise NotImplementedError
