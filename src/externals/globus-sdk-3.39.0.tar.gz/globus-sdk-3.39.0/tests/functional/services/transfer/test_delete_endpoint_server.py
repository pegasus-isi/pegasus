import pytest


@pytest.mark.xfail
def test_delete_endpoint_server():
    raise NotImplementedError
