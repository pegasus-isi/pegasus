import pytest


@pytest.mark.xfail
def test_delete_endpoint():
    raise NotImplementedError
