import pytest


@pytest.mark.xfail
def test_task_event_list():
    raise NotImplementedError
