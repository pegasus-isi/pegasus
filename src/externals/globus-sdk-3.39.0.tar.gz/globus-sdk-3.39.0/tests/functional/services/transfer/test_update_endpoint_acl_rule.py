import pytest


@pytest.mark.xfail
def test_update_endpoint_acl_rule():
    raise NotImplementedError
