import pytest


@pytest.mark.xfail
def test_endpoint_manager_hosted_endpoint_list():
    raise NotImplementedError
