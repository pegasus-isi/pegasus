import pytest


@pytest.mark.xfail
def test_endpoint_manager_resume_tasks():
    raise NotImplementedError
