import pytest


@pytest.mark.xfail
def test_endpoint_manager_delete_pause_rule():
    raise NotImplementedError
