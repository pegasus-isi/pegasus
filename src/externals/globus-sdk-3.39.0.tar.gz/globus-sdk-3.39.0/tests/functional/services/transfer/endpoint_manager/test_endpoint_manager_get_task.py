import pytest


@pytest.mark.xfail
def test_endpoint_manager_get_task():
    raise NotImplementedError
