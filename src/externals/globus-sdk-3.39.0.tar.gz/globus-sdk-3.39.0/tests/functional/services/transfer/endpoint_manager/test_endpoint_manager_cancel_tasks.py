import pytest


@pytest.mark.xfail
def test_endpoint_manager_cancel_tasks():
    raise NotImplementedError
