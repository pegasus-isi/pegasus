import pytest


@pytest.mark.xfail
def test_endpoint_manager_update_pause_rule():
    raise NotImplementedError
