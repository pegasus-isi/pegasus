import pytest


@pytest.mark.xfail
def test_endpoint_get_activation_requirements():
    raise NotImplementedError
