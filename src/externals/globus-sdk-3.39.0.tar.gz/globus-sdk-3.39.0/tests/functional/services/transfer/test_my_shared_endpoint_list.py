import pytest


@pytest.mark.xfail
def test_my_shared_endpoint_list():
    raise NotImplementedError
