import pytest


@pytest.mark.xfail
def test_endpoint_manager_pause_rule_list():
    raise NotImplementedError
