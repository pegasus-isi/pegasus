import pytest


@pytest.mark.xfail
def test_task_successful_transfers():
    raise NotImplementedError
