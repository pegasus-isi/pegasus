import pytest


@pytest.mark.xfail
def test_endpoint_role_list():
    raise NotImplementedError
