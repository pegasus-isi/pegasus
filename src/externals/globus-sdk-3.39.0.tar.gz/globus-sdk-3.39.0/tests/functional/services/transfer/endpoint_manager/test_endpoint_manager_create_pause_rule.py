import pytest


@pytest.mark.xfail
def test_endpoint_manager_create_pause_rule():
    raise NotImplementedError
