import pytest


@pytest.mark.xfail
def test_add_endpoint_server():
    raise NotImplementedError
