import pytest


@pytest.mark.xfail
def test_my_effective_pause_rule_list():
    raise NotImplementedError
