import pytest


@pytest.mark.xfail
def test_delete_endpoint_acl_rule():
    raise NotImplementedError
