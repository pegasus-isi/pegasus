import pytest


@pytest.mark.xfail
def test_create_bookmark():
    raise NotImplementedError
