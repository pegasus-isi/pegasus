import pytest


@pytest.mark.xfail
def test_delete_bookmark():
    raise NotImplementedError
