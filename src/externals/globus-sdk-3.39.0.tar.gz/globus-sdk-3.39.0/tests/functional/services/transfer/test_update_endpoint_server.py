import pytest


@pytest.mark.xfail
def test_update_endpoint_server():
    raise NotImplementedError
