import pytest


@pytest.mark.xfail
def test_add_endpoint_role():
    raise NotImplementedError
