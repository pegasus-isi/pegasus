import pytest


@pytest.mark.xfail
def test_oauth2_token_introspect():
    raise NotImplementedError
