import pytest


@pytest.mark.xfail
def test_oauth2_start_flow():
    raise NotImplementedError
