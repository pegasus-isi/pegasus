import pytest


@pytest.mark.xfail
def test_oauth2_refresh_token():
    raise NotImplementedError
