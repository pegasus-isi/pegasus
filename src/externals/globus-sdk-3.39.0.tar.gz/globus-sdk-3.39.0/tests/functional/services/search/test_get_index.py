import pytest


@pytest.mark.xfail
def test_get_index():
    raise NotImplementedError
