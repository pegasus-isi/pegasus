import pytest


@pytest.mark.xfail
def test_create_entry():
    raise NotImplementedError
