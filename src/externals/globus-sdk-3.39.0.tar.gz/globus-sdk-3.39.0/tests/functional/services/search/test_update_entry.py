import pytest


@pytest.mark.xfail
def test_update_entry():
    raise NotImplementedError
