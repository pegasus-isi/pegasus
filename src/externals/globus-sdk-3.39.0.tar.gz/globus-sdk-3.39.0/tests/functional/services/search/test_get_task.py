import pytest


@pytest.mark.xfail
def test_get_task():
    raise NotImplementedError
