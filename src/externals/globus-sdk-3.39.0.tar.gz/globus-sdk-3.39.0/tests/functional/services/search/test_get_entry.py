import pytest


@pytest.mark.xfail
def test_get_entry():
    raise NotImplementedError
