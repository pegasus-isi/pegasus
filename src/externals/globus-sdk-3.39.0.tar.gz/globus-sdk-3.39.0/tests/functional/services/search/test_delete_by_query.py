import pytest


@pytest.mark.xfail
def test_delete_by_query():
    raise NotImplementedError
