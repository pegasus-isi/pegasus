import pytest


@pytest.mark.xfail
def test_delete_entry():
    raise NotImplementedError
