import pytest


@pytest.mark.xfail
def test_ingest():
    raise NotImplementedError
