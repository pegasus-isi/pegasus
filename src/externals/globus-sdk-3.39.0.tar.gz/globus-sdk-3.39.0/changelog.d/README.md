# Changelog Fragments

Create changelog entries with `scriv`

Use `scriv create --edit` to create a changelog fragment

Fragments are collected for release as part of `make prepare-release`
