.. ref-iam

===
IAM
===

boto.iam
--------

.. automodule:: boto.iam
   :members:   
   :undoc-members:

boto.iam.response
-----------------

.. automodule:: boto.iam.response
   :members:   
   :undoc-members:

