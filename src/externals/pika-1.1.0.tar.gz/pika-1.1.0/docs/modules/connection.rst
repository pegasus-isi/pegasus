Connection
----------
The :class:`~pika.connection.Connection` class implements the base behavior
that all connection adapters extend.

.. autoclass:: pika.connection.Connection
   :members:
