Select Connection Adapter
==========================
.. automodule:: pika.adapters.select_connection

.. autoclass:: pika.adapters.select_connection.SelectConnection
  :members:
  :inherited-members:
