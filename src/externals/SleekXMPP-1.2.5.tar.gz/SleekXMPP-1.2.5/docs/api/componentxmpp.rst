=============
ComponentXMPP
=============

.. module:: sleekxmpp.componentxmpp

.. autoclass:: ComponentXMPP
    :members:
