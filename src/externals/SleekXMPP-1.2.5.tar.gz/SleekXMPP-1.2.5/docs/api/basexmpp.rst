========
BaseXMPP
========

.. module:: sleekxmpp.basexmpp

.. autoclass:: BaseXMPP
    :members:
