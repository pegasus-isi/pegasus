Stanza Handlers
===============

The Basic Handler
-----------------
.. module:: sleekxmpp.xmlstream.handler.base

.. autoclass:: BaseHandler
    :members:

Callback
--------
.. module:: sleekxmpp.xmlstream.handler.callback

.. autoclass:: Callback
    :members:


Waiter
------
.. module:: sleekxmpp.xmlstream.handler.waiter

.. autoclass:: Waiter
    :members:
