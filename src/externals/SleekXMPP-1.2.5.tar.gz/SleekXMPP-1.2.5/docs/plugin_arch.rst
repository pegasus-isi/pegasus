Plugin Architecture
===================
