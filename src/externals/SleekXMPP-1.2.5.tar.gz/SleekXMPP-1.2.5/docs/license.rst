.. _license: 

License (MIT)
=============
.. include:: ../LICENSE
