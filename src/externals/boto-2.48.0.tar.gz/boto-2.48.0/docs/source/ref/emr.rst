.. _ref-emr:

===
EMR
===

boto.emr
--------

.. automodule:: boto.emr
   :members:
   :undoc-members:

boto.emr.connection
-------------------

.. automodule:: boto.emr.connection
   :members:
   :undoc-members:

boto.emr.step
-------------

.. automodule:: boto.emr.step
   :members:
   :undoc-members:

boto.emr.emrobject
------------------

.. automodule:: boto.emr.emrobject
   :members:
   :undoc-members:

