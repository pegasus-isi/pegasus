.. ref-kinesis

=======
Kinesis
=======

boto.kinesis
------------

.. automodule:: boto.kinesis
   :members:
   :undoc-members:

boto.kinesis.layer1
-------------------

.. automodule:: boto.kinesis.layer1
   :members:
   :undoc-members:

boto.kinesis.exceptions
-----------------------

.. automodule:: boto.kinesis.exceptions
   :members:
   :undoc-members:
